﻿using System;
using System.Windows.Forms;

namespace Flappy_Bird_Windows_Form
{
    public partial class Form1 : Form 
    {
        // Game variables
        int birdY = 200;    // Bird's Y position
        int pipeSpeed = 30; // Default pipe speed
        int gravity = 2;    // Default gravity speed (when space is not pressed)
        int score = 0;      // Default score
        bool isGameOver = false; // Flag for game over state
        bool gameStarted = false; // Flag for game start state

        public Form1()
        {
            InitializeComponent();
            // Initialize the game state 
            flappyBird.Top = birdY;  // Position the bird initially
            gameTimer.Stop(); // Ensure the timer is stopped initially
            restartButton.Visible = false; // Hide restart button initially
        }

        // Handle key down events (spacebar for jump)
        private void gamekeyisdown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Space)
            {
                if (!gameStarted) // Start game when space is pressed for the first time
                {
                    gameStarted = true;
                    gameTimer.Start();  // Start the game timer
                }

                gravity = -25; // Apply upward force to simulate jump
            }
        }

        // Handle key up events (spacebar release for gravity)
        private void gamekeyisup(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Space && !isGameOver)
            {
                gravity = 15; // Apply gravity when space is released (bring the bird down)
            }
        }

        // Main game timer event
        private void gameTimerEvent(object sender, EventArgs e)
        {
            if (isGameOver) return; // Skip game loop if the game is over

            birdY += gravity; // Apply gravity to the bird's Y position
            flappyBird.Top = birdY; // Update bird's position

            pipeBottom.Left -= pipeSpeed; // Move the bottom pipe
            pipeTop.Left -= pipeSpeed; // Move the top pipe

            // Reset pipes when they go off screen and increase score
            if (pipeBottom.Left < -150)
            {
                pipeBottom.Left = 800;
                score++;
            }
            if (pipeTop.Left < -180)
            {
                pipeTop.Left = 950;
                score++;
            }

            // Update the score label
            scoreLabel.Text = "Score: " + score;

            // Check for collisions (bird hits pipes or ground)
            if (flappyBird.Bounds.IntersectsWith(pipeBottom.Bounds) ||
                flappyBird.Bounds.IntersectsWith(pipeTop.Bounds) ||
                flappyBird.Bounds.IntersectsWith(ground.Bounds) ||
                flappyBird.Top < -25)
            {
                endGame(); // End the game if collision occurs
            }

            // Increase pipe speed after a certain score
            if (score > 5)
            {
                pipeSpeed = 15;
            }
        }

        // Handle game over state and stop the game
        private void endGame()
        {
            gameTimer.Stop(); // Stop the game loop
            scoreLabel.Text = "Game Over! Score: " + score; // Display game over message with score
            isGameOver = true; // Set the game over flag
            restartButton.Visible = true; // Show restart button when game is over
        }

        // Restart button click event
        private void restartButton_Click(object sender, EventArgs e)
        {
            // Reset game state
            score = 0;
            pipeSpeed = 30;
            gravity = 2;
            birdY = 200;
            isGameOver = false;
            gameStarted = false;

            // Reset bird and pipe positions
            flappyBird.Top = birdY;
            pipeBottom.Left = 800;
            pipeTop.Left = 950;

            // Hide restart button and show score label
            restartButton.Visible = false;

            // Reset score label
            scoreLabel.Text = "Score: " + score;

            // Start the game when space is pressed
            gameTimer.Start();

            // Make sure the form captures key events after restart
            this.Focus(); // Ensures that the form is in focus and can receive key events.

            // Re-enable key events after restart
            this.KeyDown += new KeyEventHandler(this.gamekeyisdown);
            this.KeyUp += new KeyEventHandler(this.gamekeyisup);
        }

        // Click event for score label (if needed for additional functionality)
        private void scoreLabel_Click(object sender, EventArgs e)
        {
        }

       
    }
}
